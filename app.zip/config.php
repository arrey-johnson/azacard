<?php
// config.php for cPanel deployment

define('DB_HOST', 'localhost'); // Usually 'localhost' on cPanel
define('DB_NAME', 'cpaneluser_dbname'); // Replace with your cPanel database name
define('DB_USER', 'cpaneluser_dbuser'); // Replace with your cPanel database user
define('DB_PASS', 'your_db_password');  // Replace with your cPanel database password

define('BASE_URL', 'https://zapkard.shop');
?> 